import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Inbox, Flame, Star, Rocket } from "lucide-react";
import { Starfield } from "@/components/cosmos/starfield";
import { CosmosHeader } from "@/components/cosmos/cosmos-header";
import { StatCard } from "@/components/cosmos/stat-card";
import { MakaInput } from "@/components/cosmos/maka-input";
import { Recommendations } from "@/components/cosmos/recommendations";
import { WeeklyActivity } from "@/components/cosmos/weekly-activity";
import { KnowledgeGraph } from "@/components/cosmos/knowledge-graph";
import { DestinationsGrid } from "@/components/cosmos/destinations-grid";
import { RecentActivity } from "@/components/cosmos/recent-activity";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "COSMOS-CAPTURE-OS — Command Center" },
      { name: "description", content: "Capture, organize, and explore your universes, galaxies, and planets from a single Apple-premium command center." },
      { property: "og:title", content: "COSMOS-CAPTURE-OS — Command Center" },
      { property: "og:description", content: "Capture, organize, and explore your universes, galaxies, and planets." },
    ],
  }),
  component: CommandCenter,
});

const stats = [
  { label: "Today", value: 12, delta: "+3 vs yesterday", icon: Inbox, tint: "from-cyber-violet to-cyber-blue" },
  { label: "Streak", value: "7d", delta: "🔥 on fire", icon: Flame, tint: "from-ev-orange to-cosmic-pink" },
  { label: "Total XP", value: "2,450", delta: "📈 +12% wk", icon: Star, tint: "from-cyber-blue to-cosmic-cyan" },
  { label: "Routed", value: "85%", delta: "🎯 on target", icon: Rocket, tint: "from-cosmic-pink to-cyber-violet" },
];

function CommandCenter() {
  return (
    <div className="relative min-h-[100dvh] overflow-hidden font-sans text-foreground">
      <Starfield />
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          background:
            "radial-gradient(60% 40% at 50% -10%, oklch(0.55 0.25 295 / 0.45), transparent 70%), radial-gradient(60% 40% at 100% 100%, oklch(0.7 0.2 50 / 0.18), transparent 70%)",
        }}
      />

      <div className="relative z-10 mx-auto flex w-full max-w-6xl flex-col gap-6 safe-top safe-x safe-bottom sm:gap-8">
        <CosmosHeader />

        <section className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          {stats.map((s, i) => (
            <StatCard key={s.label} {...s} index={i} />
          ))}
        </section>

        <MakaInput />

        <motion.section
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.15 }}
          className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]"
        >
          <Recommendations />
          <WeeklyActivity />
        </motion.section>

        <KnowledgeGraph />
        <DestinationsGrid />
        <RecentActivity />

        <p className="pb-2 text-center text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          Cosmos · Capture · OS — v0.1 · Cosmic Cyber Glass
        </p>
      </div>
    </div>
  );
}
