import { motion } from "framer-motion";
import {
  ListChecks,
  Brain,
  Network,
  LineChart,
  ArrowUpRight,
} from "lucide-react";
import { GlassCard } from "./glass-card";

const items = [
  { icon: ListChecks, label: "Review weekly goals", hint: "5 open" },
  { icon: Brain, label: "Check knowledge gaps", hint: "3 topics" },
  { icon: Network, label: "Explore new graph", hint: "Andromeda" },
  { icon: LineChart, label: "Review productivity", hint: "+12% wk" },
];

export function Recommendations() {
  return (
    <GlassCard className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold tracking-tight">💡 Recommendations</h3>
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          AI · live
        </span>
      </div>
      <ul className="flex flex-col gap-2">
        {items.map((it, i) => {
          const Icon = it.icon;
          return (
            <motion.li
              key={it.label}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * i, duration: 0.4 }}
            >
              <button className="group flex w-full items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-left transition hover:border-cyber-blue/30 hover:bg-white/[0.06]">
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-linear-to-br from-cyber-violet/70 to-cyber-blue/70 text-white">
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{it.label}</p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {it.hint}
                  </p>
                </div>
                <ArrowUpRight className="h-4 w-4 text-foreground/40 transition group-hover:text-cyber-blue" />
              </button>
            </motion.li>
          );
        })}
      </ul>
    </GlassCard>
  );
}