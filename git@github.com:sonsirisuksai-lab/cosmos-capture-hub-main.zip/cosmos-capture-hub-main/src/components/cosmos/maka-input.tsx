import { motion } from "framer-motion";
import {
  Paperclip,
  Link2,
  Mic,
  ImageIcon,
  Send,
  Sparkles,
} from "lucide-react";
import { useState } from "react";
import { GlassCard } from "./glass-card";
import { GradientButton } from "./gradient-button";
import { AgentAvatar } from "./agent-avatar";
import { TrendingBadge } from "./trending-badge";

const suggestions = [
  "ช่วยวางแผนโปรเจค COSMOS OS",
  "Summarize today's signals",
  "Find dormant galaxies",
];

export function MakaInput() {
  const [value, setValue] = useState("");

  return (
    <motion.section
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay: 0.1 }}
      className="flex flex-col gap-4"
    >
      <GlassCard glow="primary" className="relative overflow-hidden p-5 sm:p-7">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-linear-to-br from-cyber-violet via-cosmic-pink to-cyber-blue opacity-40 blur-3xl"
        />
        <div className="relative flex flex-col gap-5">
          <div className="flex items-center gap-2">
            <TrendingBadge tone="violet" icon={<Sparkles className="h-3 w-3" />}>
              Maka Prompt
            </TrendingBadge>
            <span className="text-xs text-muted-foreground">Talk to your cosmos</span>
          </div>

          <h2 className="text-2xl font-bold leading-tight tracking-tight sm:text-4xl">
            Capture anything.
            <span className="block text-gradient">Orbit everything.</span>
          </h2>

          <div className="glass-card rounded-2xl p-3">
            <input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="พิมพ์อะไรก็ได้... (สงสัยอะไร? อยากให้ช่วยอะไร?)"
              className="w-full bg-transparent px-2 py-2 text-sm outline-none placeholder:text-muted-foreground"
            />
            <div className="mt-2 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1">
                {[Paperclip, Link2, Mic, ImageIcon].map((Icon, i) => (
                  <button
                    key={i}
                    className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-foreground/80 transition hover:border-white/25 hover:bg-white/[0.1]"
                  >
                    <Icon className="h-4 w-4" />
                  </button>
                ))}
              </div>
              <GradientButton variant="primary" size="md">
                Launch
                <Send className="h-4 w-4" />
              </GradientButton>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button
                key={s}
                onClick={() => setValue(s)}
                className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs text-foreground/80 transition hover:border-cyber-blue/40 hover:bg-cyber-blue/10"
              >
                💡 {s}
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      <GlassCard className="p-4">
        <div className="flex items-start gap-3">
          <AgentAvatar initial="L" tone="orange" ring />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm font-semibold">🏴‍☠️ Luffy</p>
              <TrendingBadge tone="violet">Vision</TrendingBadge>
              <TrendingBadge tone="orange">⭐ 85%</TrendingBadge>
            </div>
            <p className="mt-1 text-sm text-foreground/85">
              "That's your dream! Let's make it happen. Stay bold!"
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {["Set a big goal", "Write a vision statement"].map((s) => (
                <span
                  key={s}
                  className="rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[11px] text-foreground/75"
                >
                  💡 {s}
                </span>
              ))}
            </div>
          </div>
        </div>
      </GlassCard>
    </motion.section>
  );
}