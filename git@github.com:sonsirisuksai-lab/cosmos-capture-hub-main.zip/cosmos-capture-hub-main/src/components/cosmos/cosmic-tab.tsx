import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface Tab {
  id: string;
  label: string;
  icon?: string;
}

interface Props {
  tabs: Tab[];
  active: string;
  onChange: (id: string) => void;
  className?: string;
}

export function CosmicTabs({ tabs, active, onChange, className }: Props) {
  return (
    <div
      className={cn(
        "glass-card flex w-full items-center gap-1 overflow-x-auto rounded-2xl p-1",
        className,
      )}
    >
      {tabs.map((t) => {
        const isActive = t.id === active;
        return (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            className={cn(
              "relative shrink-0 rounded-xl px-3 py-2 text-xs font-medium transition sm:text-sm",
              isActive ? "text-white" : "text-foreground/70 hover:text-foreground",
            )}
          >
            {isActive && (
              <motion.span
                layoutId="cosmic-tab-pill"
                className="absolute inset-0 -z-10 rounded-xl bg-linear-to-br from-cyber-violet to-cyber-blue glow-primary"
                transition={{ type: "spring", stiffness: 380, damping: 32 }}
              />
            )}
            <span className="flex items-center gap-1.5">
              {t.icon && <span>{t.icon}</span>}
              {t.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}