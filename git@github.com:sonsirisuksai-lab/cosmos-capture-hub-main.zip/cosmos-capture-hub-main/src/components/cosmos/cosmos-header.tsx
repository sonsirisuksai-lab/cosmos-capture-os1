import { motion } from "framer-motion";
import { Sparkles, Flame, Star } from "lucide-react";
import { useState } from "react";
import { CosmicTabs } from "./cosmic-tab";
import { TrendingBadge } from "./trending-badge";

const tabs = [
  { id: "universe", label: "Universe", icon: "🌌" },
  { id: "galaxies", label: "Galaxies", icon: "🌠" },
  { id: "planets", label: "Planets", icon: "🪐" },
  { id: "legacy", label: "Legacy", icon: "📜" },
  { id: "sim", label: "Simulation", icon: "🔮" },
];

export function CosmosHeader() {
  const [active, setActive] = useState("universe");

  return (
    <motion.header
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col gap-4"
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-linear-to-br from-cyber-violet to-cyber-blue glow-primary">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              Cosmos · Capture · OS
            </p>
            <h1 className="truncate text-base font-bold tracking-tight sm:text-lg">
              <span className="text-gradient">Command Center</span>
            </h1>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <TrendingBadge tone="orange" icon={<Flame className="h-3 w-3" />}>
            98%
          </TrendingBadge>
          <TrendingBadge tone="cyan" icon={<Star className="h-3 w-3" />}>
            2,450 XP
          </TrendingBadge>
        </div>
      </div>

      <CosmicTabs tabs={tabs} active={active} onChange={setActive} />
    </motion.header>
  );
}