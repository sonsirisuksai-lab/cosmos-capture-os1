import { motion } from "framer-motion";
import { Zap, Target, Brain } from "lucide-react";
import { GlassCard } from "./glass-card";
import { ProgressRing } from "./progress-ring";

const days = [
  { d: "Mon", v: 0.55 },
  { d: "Tue", v: 0.7 },
  { d: "Wed", v: 0.42 },
  { d: "Thu", v: 0.85 },
  { d: "Fri", v: 0.95 },
  { d: "Sat", v: 0.6 },
  { d: "Sun", v: 0.75 },
];

export function WeeklyActivity() {
  return (
    <GlassCard className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold tracking-tight">📊 Weekly Activity</h3>
        <span className="text-[10px] uppercase tracking-widest text-cyber-blue">
          85% efficient
        </span>
      </div>

      <div className="flex h-32 items-end justify-between gap-1.5">
        {days.map((d, i) => (
          <div key={d.d} className="flex h-full flex-1 flex-col items-center justify-end gap-1.5">
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: `${d.v * 100}%` }}
              transition={{ delay: 0.05 * i, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              className="w-full rounded-md bg-linear-to-t from-cyber-violet/70 via-cyber-blue/60 to-cosmic-cyan/80 shadow-[0_0_18px_-4px_oklch(0.78_0.14_215_/_0.6)]"
            />
            <span className="text-[10px] text-muted-foreground">{d.d}</span>
          </div>
        ))}
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2">
        <MiniStat icon={Zap} label="Efficiency" value="94%" />
        <MiniStat icon={Target} label="Flow" value="3.2h" />
        <MiniStat icon={Brain} label="Focus" value="68%" ring />
      </div>
    </GlassCard>
  );
}

function MiniStat({
  icon: Icon,
  label,
  value,
  ring,
}: {
  icon: typeof Zap;
  label: string;
  value: string;
  ring?: boolean;
}) {
  return (
    <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3">
      {ring ? (
        <ProgressRing value={68} size={44} stroke={5} />
      ) : (
        <div className="grid h-9 w-9 place-items-center rounded-lg bg-linear-to-br from-cyber-violet/70 to-cyber-blue/70 text-white">
          <Icon className="h-4 w-4" />
        </div>
      )}
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-sm font-semibold">{value}</p>
      </div>
    </div>
  );
}