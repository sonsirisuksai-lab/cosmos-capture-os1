import { forwardRef, type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";

interface CosmicInputProps extends InputHTMLAttributes<HTMLInputElement> {
  leading?: ReactNode;
  trailing?: ReactNode;
}

export const CosmicInput = forwardRef<HTMLInputElement, CosmicInputProps>(
  ({ className, leading, trailing, ...rest }, ref) => (
    <div className="glass-card flex items-center gap-2 rounded-2xl px-3 py-2">
      {leading ? <span className="text-muted-foreground">{leading}</span> : null}
      <input
        ref={ref}
        className={cn(
          "min-w-0 flex-1 bg-transparent py-2 text-sm outline-none placeholder:text-muted-foreground",
          className,
        )}
        {...rest}
      />
      {trailing}
    </div>
  ),
);
CosmicInput.displayName = "CosmicInput";