import { motion } from "framer-motion";
import { GlassCard } from "./glass-card";

// deterministic-ish node layout
const nodes = [
  { id: "a", x: 50, y: 50, r: 8, tone: "violet" },
  { id: "b", x: 20, y: 30, r: 5, tone: "cyan" },
  { id: "c", x: 80, y: 28, r: 6, tone: "cyan" },
  { id: "d", x: 30, y: 78, r: 4, tone: "orange" },
  { id: "e", x: 72, y: 80, r: 5, tone: "violet" },
  { id: "f", x: 12, y: 60, r: 3, tone: "cyan" },
  { id: "g", x: 88, y: 60, r: 4, tone: "violet" },
  { id: "h", x: 50, y: 18, r: 3, tone: "orange" },
  { id: "i", x: 50, y: 88, r: 3, tone: "cyan" },
] as const;

const edges: [string, string][] = [
  ["a", "b"], ["a", "c"], ["a", "d"], ["a", "e"],
  ["b", "f"], ["c", "g"], ["d", "i"], ["e", "i"],
  ["b", "h"], ["c", "h"], ["a", "h"], ["a", "i"],
];

const toneFill: Record<string, string> = {
  violet: "oklch(0.62 0.22 295)",
  cyan: "oklch(0.82 0.16 220)",
  orange: "oklch(0.78 0.2 50)",
};

export function KnowledgeGraph() {
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));

  return (
    <GlassCard className="relative overflow-hidden p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold tracking-tight">🕸️ Knowledge Graph</h3>
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          3D · constellation
        </span>
      </div>
      <div className="relative aspect-[16/9] w-full overflow-hidden rounded-2xl border border-white/10 bg-[oklch(0.1_0.04_280)]/60">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(50% 60% at 50% 50%, oklch(0.45 0.2 295 / 0.35), transparent 70%)",
          }}
        />
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
          {edges.map(([a, b], i) => {
            const na = byId[a];
            const nb = byId[b];
            return (
              <motion.line
                key={i}
                x1={na.x}
                y1={na.y}
                x2={nb.x}
                y2={nb.y}
                stroke="oklch(0.82 0.16 220 / 0.35)"
                strokeWidth={0.25}
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ pathLength: 1, opacity: 1 }}
                transition={{ delay: 0.05 * i, duration: 0.8 }}
              />
            );
          })}
          {nodes.map((n, i) => (
            <motion.circle
              key={n.id}
              cx={n.x}
              cy={n.y}
              r={n.r * 0.35}
              fill={toneFill[n.tone]}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: [0, 1.2, 1], opacity: 1 }}
              transition={{ delay: 0.4 + i * 0.05, duration: 0.6 }}
              style={{ filter: "drop-shadow(0 0 4px currentColor)" }}
            />
          ))}
        </svg>
      </div>
    </GlassCard>
  );
}