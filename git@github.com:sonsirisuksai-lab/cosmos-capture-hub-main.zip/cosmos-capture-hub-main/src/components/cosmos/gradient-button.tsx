import { forwardRef, type ButtonHTMLAttributes } from "react";
import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "@/lib/utils";

type Variant = "primary" | "accent" | "orange" | "ghost";

const variantMap: Record<Variant, string> = {
  primary:
    "bg-linear-to-br from-cyber-violet to-cyber-blue text-white glow-primary",
  accent:
    "bg-linear-to-br from-cyber-blue to-cosmic-cyan text-[oklch(0.15_0.04_280)] glow-accent",
  orange:
    "bg-linear-to-br from-ev-orange to-[oklch(0.78_0.2_70)] text-[oklch(0.15_0.04_40)] glow-orange",
  ghost:
    "bg-white/[0.04] border border-white/10 text-foreground hover:bg-white/[0.08]",
};

type Props = Omit<HTMLMotionProps<"button">, "ref"> & {
  variant?: Variant;
  size?: "sm" | "md" | "lg";
} & Pick<ButtonHTMLAttributes<HTMLButtonElement>, "type">;

const sizeMap = {
  sm: "px-3 py-1.5 text-xs",
  md: "px-4 py-2.5 text-sm",
  lg: "px-5 py-3 text-base",
};

export const GradientButton = forwardRef<HTMLButtonElement, Props>(
  ({ variant = "primary", size = "md", className, children, ...rest }, ref) => (
    <motion.button
      ref={ref}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.96 }}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-xl font-medium tracking-tight transition",
        sizeMap[size],
        variantMap[variant],
        className,
      )}
      {...rest}
    >
      {children}
    </motion.button>
  ),
);
GradientButton.displayName = "GradientButton";