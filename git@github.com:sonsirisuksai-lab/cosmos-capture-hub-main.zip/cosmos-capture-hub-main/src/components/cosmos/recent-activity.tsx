import { Lightbulb, FileText, Link2, BookOpen } from "lucide-react";
import { GlassCard } from "./glass-card";
import { ActivityCard } from "./activity-card";

const items = [
  {
    icon: Lightbulb,
    title: "Idea Spark",
    body: "สร้าง AI ที่ช่วยจดบันทึก & เชื่อมโยงความรู้อัตโนมัติ",
    xp: 100,
    ago: "2h ago",
    tags: ["idea", "ai", "project"],
  },
  {
    icon: FileText,
    title: "Meeting Note",
    body: "Weekly sync with team — roadmap Q4, hiring, OKRs",
    xp: 50,
    ago: "5h ago",
    tags: ["meeting", "work"],
  },
  {
    icon: Link2,
    title: "Link",
    body: "https://github.com/sonsirisuksai-lab/cosmos-capture-os1",
    xp: 30,
    ago: "1d ago",
    tags: ["link", "reference"],
  },
  {
    icon: BookOpen,
    title: "Knowledge",
    body: "Graph Theory · concepts, algorithms, applications",
    xp: 30,
    ago: "1d ago",
    tags: ["learn", "graph"],
  },
];

export function RecentActivity() {
  return (
    <GlassCard className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold tracking-tight">📜 Recent Activity</h3>
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          24 items
        </span>
      </div>
      <div className="flex flex-col gap-2">
        {items.map((it, i) => (
          <ActivityCard key={it.title} index={i} {...it} />
        ))}
      </div>
    </GlassCard>
  );
}