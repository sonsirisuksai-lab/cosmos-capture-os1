import { forwardRef, type HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Glow = "none" | "primary" | "accent" | "orange";

interface GlassCardProps extends HTMLAttributes<HTMLDivElement> {
  glow?: Glow;
  interactive?: boolean;
}

const glowMap: Record<Glow, string> = {
  none: "",
  primary: "glow-primary",
  accent: "glow-accent",
  orange: "glow-orange",
};

export const GlassCard = forwardRef<HTMLDivElement, GlassCardProps>(
  ({ className, glow = "none", interactive, children, ...rest }, ref) => (
    <div
      ref={ref}
      className={cn(
        "glass-card rounded-3xl",
        glowMap[glow],
        interactive &&
          "transition duration-300 hover:-translate-y-0.5 hover:border-white/25",
        className,
      )}
      {...rest}
    >
      {children}
    </div>
  ),
);
GlassCard.displayName = "GlassCard";