import { cn } from "@/lib/utils";

interface Props {
  initial: string;
  tone?: "violet" | "cyan" | "orange";
  size?: number;
  ring?: boolean;
  className?: string;
}

const tones = {
  violet: "from-cyber-violet to-cyber-blue",
  cyan: "from-cyber-blue to-cosmic-cyan",
  orange: "from-ev-orange to-[oklch(0.8_0.18_60)]",
};

export function AgentAvatar({ initial, tone = "violet", size = 40, ring, className }: Props) {
  return (
    <div
      style={{ width: size, height: size }}
      className={cn("relative shrink-0", className)}
    >
      {ring && (
        <span className="pulse-ring absolute inset-0 rounded-full border border-cyber-blue/40" />
      )}
      <div
        className={cn(
          "grid h-full w-full place-items-center rounded-full bg-linear-to-br text-sm font-bold text-white shadow-[0_8px_30px_-8px_oklch(0.55_0.22_295_/_0.7)]",
          tones[tone],
        )}
      >
        {initial}
      </div>
    </div>
  );
}