import { motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import { GlassCard } from "./glass-card";

interface StatCardProps {
  label: string;
  value: string | number;
  delta?: string;
  hint?: string;
  icon: LucideIcon;
  tint?: string;
  index?: number;
}

export function StatCard({
  label,
  value,
  delta,
  hint,
  icon: Icon,
  tint = "from-cyber-violet to-cyber-blue",
  index = 0,
}: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
    >
      <GlassCard interactive className="group relative overflow-hidden p-5">
        <div
          aria-hidden
          className={`pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-linear-to-br ${tint} opacity-40 blur-2xl transition group-hover:opacity-70`}
        />
        <div className="relative flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
              {label}
            </p>
            <p className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
              {value}
            </p>
            {delta ? (
              <p className="mt-1 text-xs font-medium text-cyber-blue/90">{delta}</p>
            ) : null}
            {hint ? (
              <p className="mt-0.5 text-[11px] text-muted-foreground">{hint}</p>
            ) : null}
          </div>
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl border border-white/10 bg-white/5">
            <Icon className="h-5 w-5 text-foreground/90" />
          </div>
        </div>
      </GlassCard>
    </motion.div>
  );
}