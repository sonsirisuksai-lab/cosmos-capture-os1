import { motion } from "framer-motion";
import { GlassCard } from "./glass-card";

const items = [
  { emoji: "📝", name: "Notion", sub: "Notes", used: 12, tone: "from-cyber-violet/70 to-cyber-blue/40" },
  { emoji: "🪨", name: "Obsidian", sub: "Vault", used: 8, tone: "from-cosmic-pink/70 to-cyber-violet/50" },
  { emoji: "🗒️", name: "Apple Notes", sub: "Quick", used: 5, tone: "from-cyber-blue/70 to-cosmic-cyan/50" },
  { emoji: "✅", name: "Todoist", sub: "Tasks", used: 15, tone: "from-ev-orange/70 to-[oklch(0.8_0.18_60)]/40" },
  { emoji: "📚", name: "Readwise", sub: "Highlights", used: 22, tone: "from-cosmic-cyan/70 to-cyber-blue/50" },
  { emoji: "🎙️", name: "Voice", sub: "Memo", used: 4, tone: "from-cyber-violet/70 to-cosmic-pink/40" },
  { emoji: "🧠", name: "Anki", sub: "Cards", used: 7, tone: "from-cyber-blue/70 to-cyber-violet/40" },
  { emoji: "📅", name: "Calendar", sub: "Events", used: 11, tone: "from-ev-orange/70 to-cosmic-pink/40" },
];

export function DestinationsGrid() {
  return (
    <GlassCard className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold tracking-tight">🎯 Destinations (40+)</h3>
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          routed today
        </span>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {items.map((it, i) => (
          <motion.button
            key={it.name}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            whileHover={{ y: -3 }}
            transition={{ delay: 0.04 * i, duration: 0.4 }}
            className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-3 text-left transition hover:border-white/25"
          >
            <div
              aria-hidden
              className={`pointer-events-none absolute -right-6 -top-6 h-20 w-20 rounded-full bg-linear-to-br ${it.tone} opacity-40 blur-2xl transition group-hover:opacity-70`}
            />
            <div className="relative">
              <div className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/[0.06] text-lg">
                {it.emoji}
              </div>
              <p className="mt-3 truncate text-sm font-semibold">{it.name}</p>
              <p className="truncate text-[11px] text-muted-foreground">{it.sub}</p>
              <p className="mt-2 text-[10px] uppercase tracking-widest text-cyber-blue">
                {it.used} used
              </p>
            </div>
          </motion.button>
        ))}
      </div>
    </GlassCard>
  );
}