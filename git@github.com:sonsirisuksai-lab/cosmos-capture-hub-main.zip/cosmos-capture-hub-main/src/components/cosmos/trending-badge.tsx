import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type Tone = "violet" | "cyan" | "orange" | "neutral";

const toneMap: Record<Tone, string> = {
  violet: "border-cyber-violet/30 bg-cyber-violet/10 text-foreground",
  cyan: "border-cyber-blue/30 bg-cyber-blue/10 text-cyber-blue",
  orange: "border-ev-orange/30 bg-ev-orange/10 text-ev-orange",
  neutral: "border-white/10 bg-white/[0.04] text-foreground/80",
};

interface Props {
  children: ReactNode;
  tone?: Tone;
  icon?: ReactNode;
  className?: string;
}

export function TrendingBadge({ children, tone = "neutral", icon, className }: Props) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium tracking-tight",
        toneMap[tone],
        className,
      )}
    >
      {icon}
      {children}
    </span>
  );
}