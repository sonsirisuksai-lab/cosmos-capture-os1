import { motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import { TrendingBadge } from "./trending-badge";

interface ActivityCardProps {
  icon: LucideIcon;
  title: string;
  body: string;
  xp: number;
  ago: string;
  tags?: string[];
  index?: number;
}

export function ActivityCard({
  icon: Icon,
  title,
  body,
  xp,
  ago,
  tags = [],
  index = 0,
}: ActivityCardProps) {
  return (
    <motion.article
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.45 }}
      className="group flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-white/20 hover:bg-white/[0.06]"
    >
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-cyber-violet/80 to-cyber-blue/80 text-white">
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <h4 className="truncate text-sm font-semibold">{title}</h4>
          <TrendingBadge tone="cyan">+{xp} XP</TrendingBadge>
        </div>
        <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{body}</p>
        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          {tags.map((t) => (
            <span
              key={t}
              className="rounded-full bg-white/[0.04] px-2 py-0.5 text-[10px] text-foreground/70"
            >
              #{t}
            </span>
          ))}
          <span className="ml-auto text-[10px] text-muted-foreground">{ago}</span>
        </div>
      </div>
    </motion.article>
  );
}