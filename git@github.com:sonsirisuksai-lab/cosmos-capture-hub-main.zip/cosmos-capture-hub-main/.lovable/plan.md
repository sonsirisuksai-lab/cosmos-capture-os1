## COSMOS-CAPTURE-OS — Cosmic Cyber Glass UI

Build out the Command Center into a full Apple-premium glass UI that fuses Cyber-Tech, EVConnect, Trovilo, Productivity Engine, NFT, Spotify and B2B Industrial influences.

### Design tokens (src/styles.css)
- Add cyber palette: `--cyber-blue #00d4ff`, `--cyber-violet #7c3aed`, `--ev-orange #ff6b00`, dark bg `#0a0a1a`.
- Add gradients: `--gradient-primary` (violet→cyan), `--gradient-orange`.
- Add `@utility` helpers: `glow-primary`, `glow-accent`, `glow-orange`, `text-gradient`, `text-gradient-orange`, `float`, `card-3d`.
- Keep existing `glass-card`, `safe-*`.
- Load Inter via `<link>` in `__root.tsx` (NOT @import).

### New UI primitives (src/components/cosmos/)
1. `glass-card.tsx` — wrapper with hover lift + optional glow variant.
2. `gradient-button.tsx` — primary / accent / orange.
3. `cosmic-input.tsx` — glass input with icon slot.
4. `stat-card.tsx` — EVConnect-style metric (icon, value, delta, sparkle).
5. `progress-ring.tsx` — SVG ring for efficiency.
6. `trending-badge.tsx` — small pill (🔥, +12%).
7. `activity-card.tsx` — NFT-row style with XP + tags.
8. `agent-avatar.tsx` — circular gradient avatar.
9. `cosmic-tab.tsx` — segmented glass tabs.

### Composite blocks (src/components/cosmos/)
- `cosmos-header.tsx` — brand + tab nav (Universe/Galaxies/Planets/Legacy/Simulation) + XP/streak badges.
- `maka-input.tsx` — multi-modal prompt (attach/link/voice/image + Send), agent reply card.
- `recommendations.tsx` — list of AI suggestions.
- `weekly-activity.tsx` — 7-bar chart + mini stat trio (Efficiency / Flow / Focus).
- `knowledge-graph.tsx` — animated SVG constellation.
- `destinations-grid.tsx` — Spotify-style tiles (Notion, Obsidian, Apple Notes, Todoist…).
- `recent-activity.tsx` — feed of items with XP.

### Page assembly
- Rewrite `src/routes/index.tsx` to compose: Starfield → CosmosHeader → StatGrid(4) → MakaInput + AgentReply → Recommendations + WeeklyActivity (2-col on lg) → KnowledgeGraph → DestinationsGrid → RecentActivity.
- Mobile-first responsive; safe-area padding preserved.
- Framer Motion staggered fade/slide on each section; subtle floats on key cards.

### Notes
- Use only Tailwind v4 conventions (`@utility`, no `tailwind.config.js`, no `bg-gradient-to-*` → use `bg-linear-to-*`).
- Don't hand-write `-webkit-backdrop-filter` (Lightning CSS handles it).
- All colors via semantic tokens; no raw hex in JSX.
- No backend changes; pure presentation. Mock data co-located in each component.

### Out of scope (deferred)
- Separate route files for Universe/Galaxy/Planet/Legacy/Simulation views, GlassModal, hooks (`useCosmos`, `useUniverse`, `useMaka`), Feedback widget — current request is UI shell; I'll add these once Command Center is approved or you confirm to proceed.
